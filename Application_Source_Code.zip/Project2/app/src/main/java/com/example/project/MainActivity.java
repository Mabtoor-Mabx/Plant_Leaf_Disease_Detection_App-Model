package com.example.project;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.project.ml.Model;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class MainActivity extends AppCompatActivity {

    Button camera, gallery;
    ImageView imageView;
    TextView result, desc, remed;
    int imageSize = 224;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        camera = findViewById(R.id.button);
        gallery = findViewById(R.id.button2);

        result = findViewById(R.id.result);
        imageView = findViewById(R.id.imageView);
        desc = findViewById(R.id.desc);
        remed = findViewById(R.id.remed);

        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED){
                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent, 3);
                } else {
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, 100);
                }
            }
        });
        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent cameraIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(cameraIntent, 1);
            }
        });
    }


    public void classifyImage(Bitmap image){
        try {
            Model model = Model.newInstance(getApplicationContext());

            // Creates inputs for reference.
            TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 224, 224, 3}, DataType.FLOAT32);
            ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4 * imageSize * imageSize * 3);
            byteBuffer.order(ByteOrder.nativeOrder());
            inputFeature0.loadBuffer(byteBuffer);


            int[] intValues = new int[imageSize * imageSize];
            image.getPixels(intValues, 0, image.getWidth(), 0, 0, image.getWidth(), image.getHeight());

            int pixel = 0;
            for(int i=0; i < imageSize; i ++) {
                for(int j=0; j < imageSize; j ++) {
                    int val = intValues[pixel++];
                    byteBuffer.putFloat(((val >> 16) & 0xFF) * (1.f / 1));
                    byteBuffer.putFloat(((val >> 8) & 0xFF) * (1.f / 1));
                    byteBuffer.putFloat((val >> 0xFF) * (1.f / 1));
                }
            }

            // Runs model inference and gets result.
            Model.Outputs outputs = model.process(inputFeature0);
            TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();

            float[] confidence = outputFeature0.getFloatArray();
            int maxPos = 0;
            float maxConfidence =0;
            for (int i = 0; i < confidence.length; i++) {
                if (confidence[i] > maxConfidence) {
                    maxConfidence = confidence[i];
                    maxPos = i;
                }
            }
            String[] classes = {"Apple_scab",
                    "Apple_black_rot",
                    "Apple_cedar_apple_rust",
                    "Apple_healthy",
                    "Background_without_leaves",
                    "Blueberry_healthy",
                    "Cherry_powdery_mildew",
                    "Cherry_healthy",
                    "Corn_gray_leaf_spot",
                    "Corn_common_rust",
                    "Corn_northern_leaf_blight",
                    "Corn_healthy",
                    "Grape_black_rot",
                    "Grape_black_measles",
                    "Grape_leaf_blight",
                    "Grape_healthy",
                    "Orange_haunglongbing",
                    "Peach_bacterial_spot",
                    "Peach_healthy",
                    "Pepper_bacterial_spot",
                    "Pepper_healthy",
                    "Potato_early_blight",
                    "Potato_healthy",
                    "Potato_late_blight",
                    "Raspberry_healthy",
                    "Soybean_healthy",
                    "Squash_powdery_mildew",
                    "Strawberry_healthy",
                    "Strawberry_leaf_scorch",
                    "Tomato_bacterial_spot",
                    "Tomato_early_blight",
                    "Tomato_healthy",
                    "Tomato_late_blight",
                    "Tomato_leaf_mold",
                    "Tomato_septoria_leaf_spot",
                    "Tomato_spider_mites_two-spotted_spider_mite",
                    "Tomato_target_spot",
                    "Tomato_mosaic_virus",
                    "Tomato_yellow_leaf_curl_virus"};
            result.setText(classes[maxPos]);

            String[] classes_desc = {"Apple scab is the most common disease of apple. Scab is caused by a fungus that infects both leaves and fruit. Infected leaves have olive green to brown spots. Leaves with many leaf spots turn yellow and fall off early. Leaf loss weakens the tree when it occurs many years in a row.",


                    "Black rot is an important disease of apple caused by the fungus Botryosphaeria obtusa. Black rot fungus infects a wide variety of hardwood trees, including apple and pear.  Leaf infections result in a disease called frog-eye leaf spot.On leaves, the disease first appears as a tiny purple fleck which eventually enlarges into a circular lesion about 4-5 mm in diameter. The disease often first shows up one to three weeks after petal fall. As the lesion enlarges, the margin remains purple while the centre turns tan or brown with a light centre giving the lesion a frog-eye appearance.The optimum temperature for leaf infections is around 26.6°C with 4.5 hours of leaf wetness.",


                    "Cedar-apple rust and similar rusts are incited by several species of the fungal genus Gymnosporangium. Cedar-apple rust affects the health and vigor of apple trees since it causes premature defoliation and reduces fruit quality. If severe infections occur for several seasons, the result may be tree death. On apple, the disease first appears on the leaves as small greenish yellow spots which gradually enlarge, changing to orange-yellow and becoming surrounded at the border by concentric red bands.",


                    "A healthy Apple Leaf.",


                    "This is a BackGround without leaves.",


                    "This is a healthy blueberry leaf. Well did you know what blueberry leaves have many times more antioxidants than the fruit? Blueberries and blueberry leaves are showing positive results towards help treat neurodegenerative diseases, reducing the risk of type 2 diabetes, and helping with inflammation related to allergies.",


                    "Powdery mildew of sweet and sour cherry is caused by Podosphaera clandestina, an obligate biotrophic fungus. Mid- and late-season sweet cherry (Prunus avium) cultivars are commonly affected, rendering them unmarketable due to the covering of white fungal growth on the cherry surface.",


                    "The leaves of Wild cherry are ovate to heart-shaped. The leaves are up to 12 cm (4.7 in) long. At the leaf stalk are two nectar glands. The leaf margin is serrated, often double serrated.",


                    "Gray leaf spot is typically the most serious foliar disease of corn. Gray leaf spot requires extended periods of high humidity and warm conditions. The disease first appears in the form of small, necrotic spots with halos. These usually expand to become rectangular lesions, about 1/8 inch wide by up to 2 inches to 3 inches long and gray to brown in appearance. Mature lesions usually have distinct parallel edges and appear opaque when put up to the light, but the lesions hybrids vary widely in shape and color.",


                    "Common corn rust, caused by the fungus Puccinia sorghi, is the most frequently occurring of the two primary rust diseases of corn. These can be easily recognized and distinguished from other diseases by the development of dark, reddish-brown pustules (uredinia) scattered over both the upper and lower surfaces of the corn leaves. These pustules may appear on any above ground part of the plant, but are most abundant on the leaves.",


                    "Typical symptoms of northern corn leaf blight are canoe-shaped lesions 1 inch to 6 inches long. The lesions are initially bordered by gray-green margins. They eventually turn tan colored and may contain dark areas of fungal sporulation. The length or size of lesions may vary with in different corn hybrids reactions with different resistance genes. Lesions begin on the lower leaves and then spread to upper leaves.",


                    "This is a Healthy Corn leaf. It is used to make cornmeal pancakes, dried corn pudding, dried corn pie, etc. It can also serve as a heating fuel. Corn leaf can be dried and ground into flour to make porridge, breads and drinks.",


                    "Grape black rot is a fungal disease caused by an ascomycetous fungus, Guignardia bidwellii, that attacks grape vines during hot and humid weather.  It can cause complete crop loss in warm, humid climates, but is virtually unknown in regions with arid summers. The name comes from the black fringe that borders growing brown patches on the leaves. The disease also attacks other parts of the plant, all green parts of the vine: the shoots, leaf and fruit stems, tendrils, and fruit. The most damaging effect is to the fruit.",

                    "Grapevine measles, also called esca, black measles or Spanish measles, has long plagued grape growers with its cryptic expression of symptoms and, for a long time, a lack of identifiable causal organism(s). The name ‘measles’ refers to the superficial spots found on the fruit. Leaf symptoms are characterized by a ‘tiger stripe’ pattern when infections are severe from year to year. Mild infections can produce leaf symptoms that can be confused with other diseases or nutritional deficiencies.",



                    "Grape Isariopsis is a genus of fungi in the family Mycosphaerellaceae. The plant disease called isariopsis leaf spot is actually caused by Pseudocercospora vitis, formerly known as I. vitis.",


                    "This is a heathy grape leaf. For general health and wellness, grape leaves are a good source of nutrients, including vitamins C, E, A, K and B6, plus niacin, iron, fiber, riboflavin, folate, calcium, magnesium, copper and manganese.",


                    "Citrus greening disease 'yellow dragon disease'; or HLB is a disease of citrus caused by a vector-transmitted pathogen. The causative agents are motile bacteria, Liberibacter spp. HLB is distinguished by the common symptoms of yellowing of the veins and adjacent tissues; followed by splotchy mottling of the entire leaf, premature defoliation, dieback of twigs, decay of feeder rootlets and lateral roots, and decline in vigor, ultimately followed by the death of the entire plant. Affected trees have stunted growth, bear multiple off-season flowers (most of which fall off), and produce small, irregular ly shaped fruit with a thick, pale peel that remains green at the bottom and tastes very bitter.",



                    "Bacterial leaf spot of peach, also known as bacterial shot hole, is a common disease on older peach trees and nectarines. This peach tree leaf spot disease is caused by the bacterium Xanthomonas campestris pv. pruni. The most characteristic sign of peach tree leaf spot are angular purple to purple-brown spots on foliage, followed by the center of lesion falling out, giving the leaves a “shot hole” appearance. Leaves soon turn yellow and drop.",


                    "This is a healthy peach leaf. It's a natural antioxidant. Peach Leaf extract can help fight free radicals that cause wrinkles, dark spots, uneven skin tone and other signs of aging. It helps calm irritation. Peach Leaf extract is rich in phenolic compounds, which means it can help soothe and calm irritated skin and diminish inflammation.",


                    "Bacterial leaf spot, caused by Xanthomonas campestris pv. vesicatoria, is the most common and destructive disease for peppers. Disease symptoms can appear throughout the above-ground portion of the plant, which may include leaf spot, fruit spot and stem canker. However, early symptoms show up as water-soaked lesions on leaves that can quickly change from green to dark brown and enlarge into spots that are up to 1/4 inch in diameter with slightly raised margins.",

                    "This is a healthy Pepper bell leaf. Pepper Leaves are also very nutritious and contain high levels of Vitamin A and C. The leaves are also rich in antioxidants that can prevent damage to cells.",


                    "Early blight of potato is caused by the fungal pathogen Alternaria solani. The disease affects leaves, stems and tubers and can reduce yield, tuber size, storability of tubers, quality of fresh-market and processing tubers and marketability of the crop. The first symptoms of early blight appear as small, circular or irregular, dark-brown to black spots on the older (lower) leaves. These spots enlarge up to 3/8 inch in diameter and gradually may become angular-shaped.",


                    "Late blight is caused by the fungal-like oomycete pathogen Phytophthora infestans. The primary host is potato, but P. infestans also can infect other solanaceous plants, including tomatoes, petunias and hairy nightshade. These infected species can act as source of inoculum to potato.The first symptoms of late blight in the field are small, light to dark green, circular to irregular-shaped water-soaked spots. These lesions usually appear first on the lower leaves. Lesions often begin to develop near the leaf tips or edges, where dew is retained the longest.",


                    "This is a healthy poatato leaf.",


                    "This is a healthy Raspberry leaf. it is naturally high in vitamins and minerals we need for female health specifically: magnesium, potassium, iron, calcium, and vitamins B, A, C, and E.",



                    "This is a healthy Soyabean leaf.",


                    "Powdery mildew infections are caused by several different species of fungus. Each species has its own preferred host plants. The first sign of powdery mildew on squash are small, white, dusty spots on the young leaves. Initially, there will only be a few spots, but it spreads quickly, eventually covering the entire leaf surface. Powdery mildew is most commonly seen on the top of the leaves, but it can also appear on the leaf undersides, the stems, and even on the fruits.",


                    "Scorched strawberry leaves are caused by a fungal infection which affects the foliage of strawberry plantings. The fungus responsible is called Diplocarpon earliana. Strawberries with leaf scorch may first show signs of issue with the development of small purplish blemishes that occur on the topside of leaves.",

                    "This is a Strawberry healthy leaf. According to the University of Maryland Medical Center, strawberry leaves are high in vitamin C, iron, and calcium, as well as contain tannins, which helps with digestion, nausea, and stomach cramps.",

                    "Bacterial spot of tomato is caused by Xanthomonas vesicatoria, Xanthomonas euvesicatoria, Xanthomonas gardneri, and Xanthomonas perforans.  These bacterial pathogens can be introduced into a garden on contaminated seed and transplants, which may or may not show symptoms.",


                    "Early blight is one of the most common tomato and potato diseases. It affects leaves, fruits and stems and can be severely yield-limiting when susceptible tomato cultivars are used and weather is favorable. Severe defoliation can occur.  In tomatoes, fruit can be damaged by sun. Initially, small dark spots form on older foliage near the ground. Leaf spots are round, brown and can grow up to 1/2 inch in diameter.",


                    "Late blight is a potentially devastating disease of tomato and potato, infecting leaves, stems, tomato fruit, and potato tubers. The disease spreads quickly in fields and can result in total crop failure if untreated. Leaves have large, dark brown blotches with a green gray edge; not confined by major leaf veins.",


                    "Tomato leaf mold is typically only an issue in greenhouse and high-tunnel tomatoes. The disease is driven by high relative humidity (greater than 85%).Foliage is often the only part of the plant directly infected. Infection will cause infected leaves to wither and die, indirectly affecting yield.",



                    "Septoria leaf spot is caused by the fungus Septoria lycopersici. This fungus can attack tomatoes at any stage of development, but symptoms usually first appear on the older, lower leaves and stems when plants are setting fruit. Symptoms usually appear on leaves, but can occur on petioles, stems, and the calyx. The first symptoms appear as small, water-soaked, circular spots 1/16 to 1/8' in diameter on the undersides of older leaves. The centers of these spots then turn gray to tan and have a dark-brown margin. The spots are distinctively circular and are often quite numerous.",



                    "Two‑spotted spider mites are occasional pests that can cause serious damage to some vegetable crops during hot dry weather. Mites can injure tomatoes, beans, muskmelons, watermelons, and sweet corn. Extended periods of hot, dry weather favors mite buildups. Infestations usually first occur at the edge of a field, typically near rank weed growth or dirt roads.",




                    "target spot of tomato is a fungal disease that attacks a diverse assortment of plants, including papaya, peppers, snap beans, potatoes, cantaloupe, and squash as well as passion flower and certain ornamentals. Target spot on tomato fruit is difficult to control because the spores, which survive on plant refuse in the soil, are carried over from season to season. Read on to learn how to treat target spot on tomatoes.",



                    "Tomato yellow leaf curl virus (TYLCV) is a DNA virus from the genus Begomovirus and the family Geminiviridae. TYLCV causes the most destructive disease of tomato, and it can be found in tropical and subtropical regions causing severe economic losses. This virus is transmitted by an insect vector from the family Aleyrodidae and order Hemiptera, the whitefly xBemisia tabaci, commonly known as the silverleaf whitefly or the sweet potato whitefly.",



                    "There are more than a dozen viruses that can infect tomatoes.The most common viruses are tomato mosaic virus (ToMV) and tobacco mosaic virus (TMV).Viruses can cause foliar and fruit symptoms. Plant viruses can only be identified by lab testing. There is no cure for plant viruses, management actions should be focused on preventing virus spread.",

                    "This a healthy Tomato leaf. Another study has shown tomato leaves and tomato stems to have higher antioxidant activity and polyphenols (plant-based micronutrients that help fight disease and improve overall health) than tomato fruits. What's most surprising is the discovery of tomatine as a cancer inhibitor"};
            desc.setText(classes_desc[maxPos]);


            String[] classes_remed = { "Planting disease resistant varieties is the best way to manage scab. Fungicides can be used to manage apple scab. Proper timing of sprays is needed for fungicides to control disease.",



                    "Managing black rot in orchards relies on the integration of cultural and chemical methods together in an integrated pest management program. There are no cultivars completely resistant to black rot, but some are less susceptible to this disease than others (Table 4-11). Selecting cultivars that are less susceptible to black rot for planting near sources of disease (woodlots) may help reduce yield losses.",



                    "Apple trees can be protected from cedar-apple rust by following a fungicide spray schedule starting at blossom time and continuing at seven-day intervals until the cedar galls have stopped spreading spores. Control on cedars can be obtained with a fungicide spray schedule from June through September at two-week intervals.",

                    "None.",


                    "None.",


                    "None.",


                    "Mix 1 tablespoon baking soda and ½ teaspoon liquid soap such as Castile soap (not detergent) in 1 gallon of water. Spray liberally, getting top and bottom leaf surfaces and any affected areas. This method may work better as a preventativemeasure, although it does have some effect on existing powdery mildew as well.",


                    "None.",


                    "Disease management tactics include using resistant corn hybrids, conventional tillage where appropriate, and crop rotation. Foliar fungicides can be effective if economically warranted. Typically they are only profitable on susceptible inbreds or susceptible hybrids under a combination of high risk conditions with high yield potential, prolonged humid conditions, and evidence of disease development.",


                    "An early fungicide application may be necessary for effective disease control. Numerous fungicides are available for rust control. Consult your local county extension office and C.O.R.N. website for the latest recommendations for efficacy. Always readthe fungicide label for rates and application timing.",


                    "Use resistant hybrids. Fungicides may be warranted on inbreds for seed production during the early stages of this disease. Crop rotation and tillage practices may be helpful in some cases.",


                    "None.",



                    "A mixture of cultural and chemical control practices can manage grape black rot disease caused by Guignardia bidwellii. Cultural control aspects involve the basics in plant care and field sanitation as well as cleanup after an infectious outbreak. Chemical control has a large influence to prevent but not eliminate disease.",



                    "Presently, there are no effective management strategies for measles. Wine grape growers with small vineyards will often have field crews remove infected fruit prior to harvest. Raisins affected by measles will be discarded during harvest or at the packing house, while table grape growers will leave affected fruit on the vine. ",


                    "Lemon grass (Cymbopogon citratus (DC) Stapf), a member of the family Poaceae, is a medicinal plant that contains compounds that can potentially control pathogen-caused plant disease and/or induce plant resistance to pathogens. This aromatic plant is cultivated for the commercial production of an essential oil that is widely used as a scenting agent in perfumery and cosmetics, in the preparation of colognes, soaps and deodorants and in the pharmaceutical industry. ",


                    "None.",


                    "Some cultural practices can be effective in managing this disease. Cultural methods include antibacterial management, sanitation, removal of infected plants, frequent scouting, and most importantly, crisis declaration. Tracking the disease will help prevent further infection in other affected areas and help mitigate more local infections if detected early enough.",


                    "Keep your peach trees healthy by properly pruning out any diseased or dead limbs and fertilize and water as necessary. Too much nitrogen can aggravate the disease. While there are no completely successful sprays for control of this disease, chemical spray with copper based bactericide and the antibiotic oxytetracycline have some effect used preventatively.",


                    "None.",


                    "The most effective management strategy is the use of pathogen-free certified seeds and disease-free transplants to prevent introduction of the pathogen into greenhouses and field production areas. It is prudent to grow own transplants under sanitary conditions to avo id importing bacterial leaf spot on seedlings purchased from off-farm sources.",

                    "None.",


                    "Since most commercially acceptable potato cultivars are susceptible to early blight, the application of foliar fungicides is the primary management tactic. Mancozeb and chlorothalonil are perhaps the most frequently used protectant fungicides for early blight management but provide insufficient control under high disease pressure. Therefore, the application of locally systemic and translaminar fungicides often is necessary for control at high levels of disease pressure, especially under irrigation.",


                    "Applying phosphorous acid to potatoes after harvest and before piling can prevent infection and the spread of late blight in storage. Use a seed piece fungicide treatment labeled for control of late blight (current list of fungicides can be found in the North Dakota Field Crop Plant Disease Management Guide, PP622). Recommended seed treatments include Revus, Reason and mancozeb.",


                    "None.",


                    "None.",

                    "None.",


                    "Your first line of defense in the squash patch is to always plant varieties with a known resistance to powdery mildew. This just makes good sense. If you never develop the infection in the first place, you’ll never have to worry about controlling it.",


                    "The primary means of strawberry leaf scorch control should always be prevention. Since this fungal pathogen overwinters on the fallen leaves of infected plants, proper garden sanitation is key. This includes the removal of infected garden debris from the strawberry patch, as well as the frequent establishment of new strawberry transplants.",


                    "None.",


                    "A plant with bacterial spot cannot be cured.  Remove symptomatic plants from the field or greenhouse to prevent the spread of bacteria to healthy plants.  Burn, bury or hot compost the affected plants and DO NOT eat symptomatic fruit. Although bacterial spot pathogens are not human pathogens, the fruit blemishes that they cause can provide entry points for human pathogens that could cause illness.",


                    "Early blight-resistant varieties are readily available.  As early blight occurs commonly in Minnesota, gardeners should look into these varieties. Resistance does not mean you will not see any early blight; rather, resistant varieties can better tolerate the pathogens, and so the damage will be less severe than with non-resistant varieties.",


                    "There are resistant varieties, though even the varieties will show some late blight symptoms when conditions are highly favorable for disease. Late blight can be a very damaging disease, so it causes alarm. Note that late blight is just one of many tomato issues, and isn’t present in Minnesota many growing seasons.",


                    "Scout for tomato leaf mold during periods of high humidity (over 85%). Optimal temperature is between 71 °F and 75 °F, but disease can occur at temperatures as low as 50 °F and as high as 90 °F. The first leaf mold infections of the season have been observed in the first week of June in Minnesota high tunnel tomatoes.",



                    "The effects of Septoria leaf spot can be minimized by following a multifaceted approach to disease management that includes sanitary, cultural, and chemical methods. It is very important to eliminate initial sources of inoculum by removing or destroying as much of the tomato debris as possible after harvest in the fall. Alternatively, in large fields where plant removal is not practical, plant debris can be covered and buried by deep plowing. These simple sanitary practices can significantly reduce disease development the following year since they remove sources of the fungus that overwinter in the soil.",


                    "Natural enemies of mites are present in and around fields and can keep mite populations low. Many insecticides used for control of insect pests severely reduce numbers of beneficial insects that keep mite populations in check. Therefore, apply insecticides only as‑needed, rather than at regularly scheduled intervals. When possible, select pesticides which will have the least impact on beneficial insects.",


                    "Remove old plant debris at the end of the growing season; otherwise, the spores will travel from debris to newly planted tomatoes in the following growing season, thus beginning the disease anew. Dispose of the debris properly and don’t place it on your compost pile unless you’re sure your compost gets hot enough to kill the spores.",



                    "Currently, the most effective treatments used to control the spread of TYLCV are insecticides and resistant crop varieties. The effectiveness of insecticides is not optimal in tropical areas due to whitefly resistance against the insecticides; therefore, insecticides should be alternated or mixed to provide the most effective treatment against virus transmission.",



                    "Many viruses cause similar symptoms, but it is impossible to confirm without a diagnosis from a plant pathology lab. Herbicide damage from products used on lawns can often be mistaken for viruses in home gardens. For information on this, see Herbicide injury on garden plants. You also can send plants to the University of Minnesota Plant Disease Clinic for diagnosis.",


                    "None."

            };
            remed.setText(classes_remed[maxPos]);


            // Releases model resources if no longer used.
            model.close();
        } catch (IOException e) {
            // TODO Handle the exception
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == 3) {
                Bitmap image = (Bitmap) data.getExtras().get("data");
                int dimension = Math.min(image.getWidth(), image.getHeight());
                image = ThumbnailUtils.extractThumbnail(image, dimension, dimension);
                imageView.setImageBitmap(image);

                image = Bitmap.createScaledBitmap(image, imageSize, imageSize, false);
                classifyImage(image);
            } else {
                Uri dat = data.getData();
                Bitmap image = null;
                try {
                    image = MediaStore.Images.Media.getBitmap(this.getContentResolver(), dat);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                imageView.setImageBitmap(image);

                image = Bitmap.createScaledBitmap(image, imageSize, imageSize, false);
                classifyImage(image);
            }

            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}



